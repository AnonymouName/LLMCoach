# Introduction
### 依赖
   + Python版本大于等于3.6
   + 请安装antlr4-python，使用pip安装``pip install antlr4-python3-runtime``
### 安装
   ...
### [使用antlr4解析scenest语言](docs/scenest-antlr4.md)
### [scenest语言-场景](docs/scenest-scenario.md)
### [scenest语言-断言](docs/scenest-assertion.md)